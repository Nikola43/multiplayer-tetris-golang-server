'use strict';

const TokenAddress = '0x64F86C595Dc917d06d6523d9B7F243e051E80162';
const TetrisGameAddress = '0x4BA7DDB8BdaE72BC360F318e5c02f2f729Ab37dC';

const TetrisGameAbi = [
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "previousOwner",
                "type": "address"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "newOwner",
                "type": "address"
            }
        ],
        "name": "OwnershipTransferred",
        "type": "event"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "name",
                "type": "string"
            },
            {
                "internalType": "uint256",
                "name": "rewardedNftType",
                "type": "uint256"
            },
            {
                "internalType": "address",
                "name": "rewardedNftAddress",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "rewardedNftId",
                "type": "uint256"
            }
        ],
        "name": "addGame",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "",
                "type": "string"
            }
        ],
        "name": "games",
        "outputs": [
            {
                "internalType": "string",
                "name": "name",
                "type": "string"
            },
            {
                "internalType": "address",
                "name": "rewardedNftAddress",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "rewardedNftType",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "rewardedNftId",
                "type": "uint256"
            },
            {
                "internalType": "bool",
                "name": "isExist",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "name",
                "type": "string"
            }
        ],
        "name": "getHighScoreAddressess",
        "outputs": [
            {
                "internalType": "address[]",
                "name": "",
                "type": "address[]"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "name",
                "type": "string"
            }
        ],
        "name": "getHighScores",
        "outputs": [
            {
                "internalType": "uint256[]",
                "name": "",
                "type": "uint256[]"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            },
            {
                "internalType": "uint256[]",
                "name": "",
                "type": "uint256[]"
            },
            {
                "internalType": "uint256[]",
                "name": "",
                "type": "uint256[]"
            },
            {
                "internalType": "bytes",
                "name": "",
                "type": "bytes"
            }
        ],
        "name": "onERC1155BatchReceived",
        "outputs": [
            {
                "internalType": "bytes4",
                "name": "",
                "type": "bytes4"
            }
        ],
        "stateMutability": "pure",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            },
            {
                "internalType": "bytes",
                "name": "",
                "type": "bytes"
            }
        ],
        "name": "onERC1155Received",
        "outputs": [
            {
                "internalType": "bytes4",
                "name": "",
                "type": "bytes4"
            }
        ],
        "stateMutability": "pure",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            },
            {
                "internalType": "bytes",
                "name": "",
                "type": "bytes"
            }
        ],
        "name": "onERC721Received",
        "outputs": [
            {
                "internalType": "bytes4",
                "name": "",
                "type": "bytes4"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "owner",
        "outputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "renounceOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "name",
                "type": "string"
            }
        ],
        "name": "resetHighScore",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "name",
                "type": "string"
            }
        ],
        "name": "sendReward",
        "outputs": [],
        "stateMutability": "payable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "name",
                "type": "string"
            },
            {
                "internalType": "uint256",
                "name": "nftType",
                "type": "uint256"
            },
            {
                "internalType": "address",
                "name": "nftAddress",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "nftId",
                "type": "uint256"
            }
        ],
        "name": "setRewardedNFT",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "string",
                "name": "name",
                "type": "string"
            },
            {
                "internalType": "uint256",
                "name": "value",
                "type": "uint256"
            }
        ],
        "name": "storeScore",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "bytes4",
                "name": "interfaceId",
                "type": "bytes4"
            }
        ],
        "name": "supportsInterface",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "newOwner",
                "type": "address"
            }
        ],
        "name": "transferOwnership",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "uint256",
                "name": "nftType",
                "type": "uint256"
            },
            {
                "internalType": "address",
                "name": "nftContractAddress",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "nftId",
                "type": "uint256"
            }
        ],
        "name": "withdrawNft",
        "outputs": [],
        "stateMutability": "nonpayable",
        "type": "function"
    }
];


// The minimum ABI required to get the ERC20 Token balance
const minABI = [
    {
        "inputs": [],
        "stateMutability": "nonpayable",
        "type": "constructor"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "owner",
                "type": "address"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "spender",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "value",
                "type": "uint256"
            }
        ],
        "name": "Approval",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "from",
                "type": "address"
            },
            {
                "indexed": true,
                "internalType": "address",
                "name": "to",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "value",
                "type": "uint256"
            }
        ],
        "name": "Transfer",
        "type": "event"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "owner",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "spender",
                "type": "address"
            }
        ],
        "name": "allowance",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "spender",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "approve",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "account",
                "type": "address"
            }
        ],
        "name": "balanceOf",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "decimals",
        "outputs": [
            {
                "internalType": "uint8",
                "name": "",
                "type": "uint8"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "spender",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "subtractedValue",
                "type": "uint256"
            }
        ],
        "name": "decreaseAllowance",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "spender",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "addedValue",
                "type": "uint256"
            }
        ],
        "name": "increaseAllowance",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "name",
        "outputs": [
            {
                "internalType": "string",
                "name": "",
                "type": "string"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "symbol",
        "outputs": [
            {
                "internalType": "string",
                "name": "",
                "type": "string"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "totalSupply",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "recipient",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "transfer",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "sender",
                "type": "address"
            },
            {
                "internalType": "address",
                "name": "recipient",
                "type": "address"
            },
            {
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            }
        ],
        "name": "transferFrom",
        "outputs": [
            {
                "internalType": "bool",
                "name": "",
                "type": "bool"
            }
        ],
        "stateMutability": "nonpayable",
        "type": "function"
    }
];


let account;
let Web3Instance;


window.addEventListener('load', async () => {
    document.getElementById("connectMetamaskButton").addEventListener("click", connectMetamask);
    document.getElementById("connectMetamaskButton2").addEventListener("click", connectMetamask);
    document.getElementById("playButton").addEventListener("click", playButtonOnClick);
    document.getElementById("storeScoreButton").addEventListener("click", storeScoreButtonOnClick);


    const width = window.innerWidth;
    const height = window.innerHeight;

    console.log(
        {
            width,
            height
        }
    )

    if (height < 800 || width < 800) {
        document.getElementById('mobileButtons').style.display = "flex";
        document.getElementById('mobileButtonsDown').style.display = "flex";
    } else {
        document.getElementById('mobileButtons').style.display = "none";
        document.getElementById('mobileButtonsDown').style.display = "none";
    }

});

async function getHighScore() {
    const contract = new window.web3.eth.Contract(TetrisGameAbi, TetrisGameAddress);
    const result = await contract.methods.getHighScores("tetris").call();
    return result && result.length > 0 ? result[result.length - 1] : 0;
}

async function storeScoreButtonOnClick() {


    const s = document.getElementById('score');

    const contract = new window.web3.eth.Contract(TetrisGameAbi, TetrisGameAddress);
    const result = await contract.methods.storeScore("tetris", s.innerHTML).send({
        from: account,
        value: 0,
        type: '0x2'
    });
    console.log(result);

    highScore = await getHighScore();
    $('p#highScoreLabel').text(highScore.toString());

    document.getElementById('storeScoreButton').style.display = 'none';
    document.getElementById('scoreStoredLabel').style.display = 'block';

    //const node = document.createElement("p");                 // Create a <li> node
    //const textnode = document.createTextNode(account + " - " + score);         // Create a text node
    //node.appendChild(textnode);                              // Append the text to <li>
    //document.getElementById("rankingList").appendChild(node);
}


// tslint:disable-next-line:typedef
function percentage(percent, total) {
    return ((percent / 100) * total);
}

async function playButtonOnClick() {
    await play();
}

async function networkSelectChange() {

    const netWork = {

        index: 0,
        image: 'https://s2.coinmarketcap.com/static/img/coins/64x64/1839.png',
        name: 'Binance Smart Chain',
        params: {
            chainId: '0x38',
            chainName: 'Binance Smart Chain Mainnet',
            nativeCurrency: {
                name: 'Binance Coin',
                symbol: 'BNB',
                decimals: 18
            },
            rpcUrls: ['https://bsc-dataseed.binance.org/'],
            blockExplorerUrls: ['https://bscscan.com']

        },
    };

    try {
        await window.web3.request({
            method: 'wallet_switchEthereumChain',
            params: [{chainId: netWork.params.chainId}],
        });
    } catch (switchError) {
        // This error code indicates that the chain has not been added to MetaMask.
        if (switchError.code === 4902) {
            try {
                await window.web3.request({
                    method: 'wallet_addEthereumChain',
                    params: [netWork.params]
                });
            } catch (addError) {
                // handle "add" error
                console.log(addError);
            }
        }
        // handle other "switch" errors
        console.log(switchError);

        // rejected
        if (switchError.code === 4001) {

        }
    }
}

/*
async function play() {
    const contract = new window.web3.eth.Contract(TetrisGameAbi, TetrisGameAddress);
    const result = await contract.methods.play(100000000).call(); // 29803630997051883414242659
    console.log(result)
}
*/

async function getTokensBalance(account, tokenAddress) {

    const contract = new window.web3.eth.Contract(minABI, tokenAddress);
    const result = await contract.methods.balanceOf(account).call(); // 29803630997051883414242659


    return result;
}

async function f() {

    console.log('transfer.service :: getAccount :: start');
    if (account == null) {
        // await networkSelectChange();
        account = await new Promise((resolve, reject) => {
            console.log('transfer.service :: getAccount :: eth');
            console.log(window.web3.eth);

            window.web3.eth.getAccounts(async (err, retAccount) => {
                console.log('transfer.service :: getAccount: retAccount');
                console.log(retAccount);
                if (retAccount.length > 0) {
                    console.log(retAccount);
                    //$('button#connectMetamaskButton').text(retAccount[0]);
                    let walletAddress = "";
                    walletAddress += retAccount[0].charAt(0);
                    walletAddress += retAccount[0].charAt(1);
                    walletAddress += retAccount[0].charAt(2);
                    walletAddress += retAccount[0].charAt(3);
                    walletAddress += retAccount[0].charAt(4);
                    walletAddress += retAccount[0].charAt(5);
                    walletAddress += retAccount[0].charAt(6);
                    walletAddress += '...';
                    walletAddress += retAccount[0][retAccount[0].length - 6];
                    walletAddress += retAccount[0][retAccount[0].length - 5];
                    walletAddress += retAccount[0][retAccount[0].length - 4];
                    walletAddress += retAccount[0][retAccount[0].length - 3];
                    walletAddress += retAccount[0][retAccount[0].length - 2];
                    walletAddress += retAccount[0][retAccount[0].length - 1];

                    document.getElementById('connectMetamaskButton').innerHTML = walletAddress
                    document.getElementById('connectMetamaskButton2').innerHTML = walletAddress
                    highScore = await getHighScore();
                    $('p#highScoreLabel').text(highScore.toString());
                    tokenBalance = await getTokensBalance(retAccount[0], TokenAddress)
                    tokenBalance = 10;
                    console.log(tokenBalance)

                    document.getElementById('playButton').style.display = "block"

                    if (tokenBalance === 0) {
                        document.getElementById('insufficient').style.display = "block";
                        document.getElementById('playButton').style.display = "block"
                        document.getElementById('playButton').innerHTML = "Buy Token"
                    } else {
                        document.getElementById('insufficient').style.display = "none";
                        document.getElementById('playButton').innerHTML = "Play"
                    }


                    resolve(retAccount[0]);
                } else {
                    // alert('transfer.service :: getAccount :: no accounts found.');
                    reject('No accounts found.');
                }
                if (err != null) {
                    // alert('transfer.service :: getAccount :: error retrieving account');
                    reject('Error retrieving account');
                }
            });
        });
    }
    return Promise.resolve(account);
}

async function connectMetamask() {
    if (window.ethereum) {
        window.web3 = new Web3(ethereum);
        Web3Instance = window.web3;
        try {
            // Request account access if needed
            await ethereum.enable();
            // Acccounts now exposed
            await f();


            /*
            var node = document.createElement("p");                 // Create a <li> node
            var textnode = document.createTextNode("0xB06a4327FF7dB3D82b51bbD692063E9a180b79D9 - 1000");         // Create a text node
            node.appendChild(textnode);                              // Append the text to <li>
            node.appendChild(textnode);                              // Append the text to <li>
            node.appendChild(textnode);                              // Append the text to <li>
            node.appendChild(textnode);                              // Append the text to <li>
            document.getElementById("rankingList").appendChild(node);
            */


        } catch (error) {
            // User denied account access...
        }
    }
    // Legacy dapp browsers...
    else if (window.web3) {
        window.web3 = new Web3(web3.currentProvider);
        // Acccounts always exposed
        web3.eth.sendTransaction({/* ... */});
    }
    // Non-dapp browsers...
    else {
        console.log('Non-Ethereum browser detected. You should consider trying MetaMask!');
    }
}
